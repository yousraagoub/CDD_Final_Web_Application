// Elements
const emailInput = document.getElementById("email-input")
const passwordInput = document.getElementById("password-input")

const loginButton = document.getElementById("login-button")
const showPasswordButton = document.getElementsByClassName("bi-eye-slash")[0]


// Functions
function validEmail() {
    const email = emailInput.value
    let emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

    if (emailInput.value === "") {
        emailInput.classList.remove("is-valid")
        emailInput.classList.remove("is-invalid")
        emailValid = false
    }
    else if (emailValid) {
        emailInput.classList.remove("is-invalid")
        emailInput.classList.add("is-valid")
    }
    else {
        emailInput.classList.remove("is-valid")
        emailInput.classList.add("is-invalid")
    }

    return emailValid
}

function validPassword() {
    const password = passwordInput.value
    let passwordValid = password.length > 8 && /[A-Za-z]/.test(password) && /[0-9]/.test(password)

    if (passwordInput.value === "") {
        passwordInput.classList.remove("is-valid")
        passwordInput.classList.remove("is-invalid")
        passwordValid = false
    }
    else if (passwordValid) {
        passwordInput.classList.remove("is-invalid")
        passwordInput.classList.add("is-valid")
    }
    else {
        passwordInput.classList.remove("is-valid")
        passwordInput.classList.add("is-invalid")
    }

    return passwordValid
}


// Event Handlers
function toggleShowPassword() {
    if (showPasswordButton.classList.contains("bi-eye-slash")) {
        showPasswordButton.classList.replace("bi-eye-slash", "bi-eye")
        passwordInput.setAttribute("type", "text")
    }
    else {
        showPasswordButton.classList.replace("bi-eye", "bi-eye-slash")
        passwordInput.setAttribute("type", "password")
    }
}

function toggleloginButton() {
    const emailValid = validEmail()
    const passwordValid = validPassword()

    if (emailValid && passwordValid) {
        loginButton.removeAttribute("disabled")
    }
    else {
        loginButton.setAttribute("disabled", "")
    }
}


// On Load
toggleloginButton()


// Event Listeners
emailInput.addEventListener("input", toggleloginButton)
passwordInput.addEventListener("input", toggleloginButton)

showPasswordButton.addEventListener("click", toggleShowPassword)