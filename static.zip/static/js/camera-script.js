const videoElement = document.getElementById('camera-video');
const canvasElement = document.getElementById('capture-canvas');
const captureButton = document.getElementById('capture-button');
const toggleCameraButton = document.getElementById('toggle-camera');
const cameraSelect = document.getElementById('cameras');
const fileInput = document.getElementById('file-input');
const submitButton = document.getElementById('submit-button');

let mediaStream = null;
let currentDeviceId = null;

// Function to get available video input devices
async function getCameras() {
    try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter(device => device.kind === 'videoinput');

        cameraSelect.innerHTML = ''; // Clear existing options
        videoDevices.forEach((device, index) => {
            const option = document.createElement('option');
            option.value = device.deviceId;
            option.textContent = device.label || `Camera ${index + 1}`;
            cameraSelect.appendChild(option);
        });

        if (videoDevices.length > 0) {
            currentDeviceId = videoDevices[0].deviceId;
            startCamera(currentDeviceId);
        } else {
            alert('No cameras found');
        }
    } catch (error) {
        console.error('Error accessing cameras:', error);
    }
}

// Function to start the camera
async function startCamera(deviceId) {
    if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
    }

    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { deviceId: deviceId ? { exact: deviceId } : undefined },
        });
        videoElement.srcObject = mediaStream;
        videoElement.play();
    } catch (error) {
        if (error.name === 'OverconstrainedError') {
            console.error('Selected device is not available or does not support the constraints.');
            alert('Error: The selected camera is not available or does not meet the requirements.');
        } else {
            console.error('Error starting camera:', error);
        }
    }
}

// Event listener for camera selection change
cameraSelect.addEventListener('change', (event) => {
    currentDeviceId = event.target.value;
    startCamera(currentDeviceId);
});

// Event listener for capturing an image
captureButton.addEventListener('click', () => {
    const context = canvasElement.getContext('2d');
    canvasElement.width = videoElement.videoWidth;
    canvasElement.height = videoElement.videoHeight;
    context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);

    // Optionally, upload the captured image
    canvasElement.toBlob(blob => {
        const file = new File([blob], 'capture.png', { type: 'image/png' });
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;
        submitButton.removeAttribute('disabled')
    });
});

// Event listener for toggling the camera
let cameraRunning = true;
toggleCameraButton.addEventListener('click', () => {
    if (cameraRunning) {
        mediaStream.getTracks().forEach(track => track.stop());
        videoElement.srcObject = null;
    } else {
        startCamera(currentDeviceId);
    }
    cameraRunning = !cameraRunning;
});

// Initialize camera list on page load
getCameras();
