base_navbar = {
    "en": {
        "nav_links": [
            ["Home", "/"], 
            ["Upload", "/upload"], 
            ["Camera", "/camera"],
            ["History", "/history"], 
            ["Account", "/account"]
            ],
        "logout": "Logout"
        },
    "ar": {
        "nav_links": [
            ["الصفحة الرئيسية", "/"], 
            ["التحليل", "/upload"], 
            ["كاميرا", "/camera"],
            ["السجلات", "/history"], 
            ["الحساب", "/account"]
            ],
        "logout": "تسجيل الخروج"
        }
}

login_data = {
    "en": {
        "email_label": "Email Address",
        "password_label": "Password",
        "button_text": "Login",
        "register_text": ["Don't have an account?", "Register"]
    },
    "ar": {
        "email_label": "البريد الإلكتروني",
        "password_label": "كلمة المرور",
        "button_text": "تسجيل الدخول",
        "register_text": ["ليس لديك حساب؟", "إنشاء حساب"]
    }
}

register_data = {
    "en": {
        "name_rules": "No spaces, numbers, or special characters in first or last name",
        "first_name_label": "First Name",
        "last_name_label": "Last Name",
        "email_label": "Email Address",
        "password_rules": "Password should contain at least 8 characters, a letter, and a number",
        "password_label": "Password",
        "confirm-password-label": "Confirm Password",
        "button_text": "Register",
        "login_text": ["Have an account?", "Login"]
    },
    "ar": {
        "name_rules": "يسمح فقط بالأحرف دون وجود مسافات في الأسماء",
        "first_name_label": "الاسم الأول",
        "last_name_label": "اسم العائلة",
        "email_label": "البريد الإلكتروني",
        "password_rules": "يجب أن تحتوي كلمة المرور على ثمانية أحرف او أرقام و على الأقل حرف ورقم",
        "password_label": "كلمة المرور",
        "confirm-password-label": "تأكيد كلمة المرور",
        "button_text":"إنشاء حساب",
        "login_text": ["لديك حساب؟", "تسجيل الدخول"]
    }
}

def index_data(first_name):
    data = {
        "en": {
            "welcome": "Welcome",
            "first_name": first_name,
            "cards": [{
                    "image_path": "../static/images/upload-card.png",
                    "title": "Upload",
                    "text": "Select a crops image, press a button, and get the analysis with just a touch of a button",
                    "button_action": "/upload",
                    "button_text":  "Upload image"
                }, {
                    "image_path": "../static/images/camera-card.png",
                    "title": "Camera",
                    "text": "Open the camera to capture a picture of the plants and automatically analyze",
                    "button_action": "/camera",
                    "button_text":  "Take image"
                }, {
                    "image_path": "../static/images/history-card.png",
                    "title": "History",
                    "text": "View previous analyses on simple or advanced view or delete depending on your need",
                    "button_action": "/history",
                    "button_text":  "Previous results"
                }, {
                    "image_path": "../static/images/account-card.png",
                    "title": "Account",
                    "text": "View or change account information including first name, last name, email, or password",
                    "button_action": "/account",
                    "button_text":  "Account settings"
                }]
            },

            "ar": {
                "welcome": "مرحبا",
                "first_name": first_name,
                "cards": [{
                    "image_path": "../static/images/upload-card.png",
                    "title": "التحليل",
                    "text": "قم باختيار صورة المحاصيل، ثم اضغط على الزر، واحصل على التحليل بمجرد لمسة زر",
                    "button_action": "/upload",
                    "button_text": "حلل الأن"
                }, {
                    "image_path": "../static/images/camera-card.png",
                    "title": "الكاميرا",
                    "text": "افتح الكاميرا لالتقاط صورة للنباتات وإرسالها تلقائيًا للتحليل بضغطة زر ولا اكثر",
                    "button_action": "/camera",
                    "button_text":  "Take image"
                }, {
                    "image_path": "../static/images/history-card.png",
                    "title": "السجلات",
                    "text": "انتقل إلى عرض التحليلات السابقة في العرض البسيط أو المتقدم أو احذفها حسب حاجتك",
                    "button_action": "/history",
                    "button_text": "التحليلات السابقة"
                }, {
                    "image_path": "../static/images/account-card.png",
                    "title": "الحساب",
                    "text": "عرض أو تغيير معلومات الحساب بما في ذلك الاسم الأول أو اسم العائلة أو البريد الإلكتروني أو كلمة المرور",
                    "button_action": "/account",
                    "button_text": "إعدادات الحساب"
                }]
            }
        }
    return data

upload_data = {
    "en": {
        "input_label": "Image size must be less than 3MB",
        "submit_button": "Analyze image"
    },
    "ar": {
        "input_label": "حجم الصورة يجب ان يكون اقل من ثلاثة ميقا بايت",
        "submit_button": "حلل الصورة"
    }
}

def history_data(analysis):
    data = {
        "en": {
            "analysis": analysis,
            "no_analysis": "No analysis made yet",
            "view_analysis": "View Analysis",
            "delete_analysis": "Delete Analysis"
        },
        "ar": {
            "analysis": analysis,
            "no_analysis": "لم يتم إجراء أي تحليل حتى الآن",
            "view_analysis": "عرض التحليل",
            "delete_analysis": "حذف التحليل"
        }
    }
    return data

account_data = {
    "en": {
        "name_rules": "No spaces, numbers, or special characters in first or last name",
        "first_name_label": "First Name",
        "last_name_label": "Last Name",
        "email_label": "Email Address",
        "password_rules": "Password should contain at least 8 characters, a letter, and a number",
        "password_label": "New Password",
        "button_text": "Update Account"
    },
    "ar": {
        "name_rules": "يسمح فقط بالأحرف دون وجود مسافات في الأسماء",
        "first_name_label": "الاسم الأول",
        "last_name_label": "اسم العائلة",
        "email_label": "البريد الإلكتروني",
        "password_rules": "يجب أن تحتوي كلمة المرور على ثمانية أحرف او أرقام و على الأقل حرف ورقم",
        "password_label": "كلمة المرور الجديدة",
        "button_text":"تحديث الحساب",
    }
}